build-apk.yml is disabled (renamed to .disabled) because this repository has
no Android project in it -- no gradlew, no /app module, no manifest. As shipped,
the workflow would fail on every run at the "Build APK" step.

This repo is a Node/Express backend plus one static HTML page. To actually
produce an installable APK from it, you'd need to wrap the frontend in a
native shell (e.g. Capacitor or Cordova) and commit that Android project here
first -- there's no way to build an APK from a web page and a Node server
directly. Re-enable this workflow (rename it back to .yml) once that project
exists in the repo.
