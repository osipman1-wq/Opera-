function errorHandler(err, req, res, next) { // eslint-disable-line no-unused-vars
  console.error(err);
  res.status(err.status || 500).json({
    success: false,
    error: err.message || "Server error"
  });
}

module.exports = errorHandler;
